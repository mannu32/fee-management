from django.contrib import admin
from .models import Classes
from .models import Student
from .models import Fees
from .models import Yesrs
# Register your models here.

admin.site.register(Classes)
admin.site.register(Student)
admin.site.register(Fees)
admin.site.register(Yesrs)
