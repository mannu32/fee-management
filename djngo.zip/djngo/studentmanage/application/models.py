from django.db import models

# Create your models here.
class Classes(models.Model):
  name = models.CharField(max_length=255)
  section = models.CharField(max_length=255)
  def __str__(self) -> str:
        return self.name

class Student(models.Model):
  classes = models.ForeignKey('Classes',on_delete=models.CASCADE)
  name = models.CharField(max_length=255)
  father_name = models.CharField(max_length=255)
  phone = models.CharField(max_length=255)
  alt_phone = models.CharField(max_length=255)
  address = models.CharField(max_length=255)
  wallet = models.CharField(max_length=255)
  join_at = models.DateField(("Date"), auto_now_add=True)
  created_at =  models.DateField(("Date"), auto_now_add=True)
  def __str__(self) -> str:
        return self.name

class Yesrs(models.Model):
  year = models.CharField(max_length=255)
  def __str__(self) -> str:
        return self.year
  
class Fees(models.Model):
  stu_id = models.ForeignKey('Student',on_delete=models.CASCADE)
  year = models.ForeignKey('Yesrs',on_delete=models.CASCADE)
  jan = models.CharField(max_length=255,null=True,blank=True)
  fab = models.CharField(max_length=255,null=True,blank=True)
  mar = models.CharField(max_length=255,null=True,blank=True)
  apr = models.CharField(max_length=255,null=True,blank=True)
  may = models.CharField(max_length=255,null=True,blank=True)
  jun = models.CharField(max_length=255,null=True,blank=True)
  jul = models.CharField(max_length=255,null=True,blank=True)
  aug = models.CharField(max_length=255,null=True,blank=True)
  sep = models.CharField(max_length=255,null=True,blank=True)
  oct = models.CharField(max_length=255,null=True,blank=True)
  nov = models.CharField(max_length=255,null=True,blank=True)
  dec = models.CharField(max_length=255,null=True,blank=True)
  def __str__(self) -> str:
        return self.jan